
const restaurantDetails = (info) => {
    return {
        type: "RESTAURANT_INFO",
        payload: info
    };
};

export default restaurantDetails;