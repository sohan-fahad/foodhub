
const closeHeaderPopup = () => {
    return {
        type: "CLOSE_HEADER_POPUP"
    }
};

export default closeHeaderPopup;