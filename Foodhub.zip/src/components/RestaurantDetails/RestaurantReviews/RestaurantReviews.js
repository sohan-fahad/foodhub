import React from "react";

const RestaurantReviews = () => {
  return <div>sdfaads</div>;
};

export default RestaurantReviews;
