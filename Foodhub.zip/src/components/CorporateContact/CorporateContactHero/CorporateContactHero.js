import React from 'react';
import "./CorporateContactHero.css"

const CorporateContactHero = () => {
    return (
        <div className='CorporateContactHero'>
            <h1 className="CorporateContactHero__title">Contact  | Foodhub</h1>
        </div>
    );
};

export default CorporateContactHero;