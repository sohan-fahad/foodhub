export const delivery = () => {
    return {
        type: "DELIVERY"
    }
};


export const pickUp = () => {
    return {
        type: "PICKUP"
    }
};
