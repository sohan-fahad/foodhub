import React from "react";

const PaymentGateWay = () => {
  return <div className="PaymentGateWay"></div>;
};

export default PaymentGateWay;
