const cartObject = (obj) => {
    return {
        type: "CART_ITEMS",
        cartObject: obj
    }
};

export default cartObject;